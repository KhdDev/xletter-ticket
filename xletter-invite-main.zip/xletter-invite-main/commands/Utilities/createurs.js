const Discord = require("discord.js");

exports.run = async (bot, message, args, functions) => {
        const member = message.member;
        const user = message.mentions.members.first();

let embed = new Discord.MessageEmbed()
.setTitle(`:tickets: DeltaTickets - Les créateurs`)
.setColor("RANDOM")
.setImage("https://i.imgur.com/MDQHYtz.png")
.setDescription("● Hey salut **"+ member.user.username+"**, voici les créateurs de XletterTickets\n● XletterTickets créé par la société de XletterProject \n\n<a:fleche:771373429366587402> **Date de création:** Crée le 28 août 2020\n<a:fleche:771373429366587402> **Créateur:** Khd'CP-0#0667 & XletterProject.")
.setFooter(`XletterTickets | Crée par XletterProject.`, bot.user.displayAvatarURL())
.setTimestamp();

message.channel.send(embed);
};

exports.help = {
    name: "createurs",
    aliases: ['crea', "fonda"]
}