const Discord = require("discord.js");
const moment = require("moment");
require("moment-duration-format");
const bot = new Discord.Client({fetchAllMembers: true})

exports.run = async (bot, message, args, functions) => {
  const duration = moment.duration(bot.uptime).format(" D [jrs], H [hrs], M [mins], S [secs]");
  const embed = new Discord.MessageEmbed()
    .setAuthor(`XletterTickets v2.0`, bot.avatarURL)
    .setColor(0x00AE86)
    .setThumbnail(bot.avatarURL)
    .setTimestamp()
    .setFooter(`XletterTickets | Crée par XletterProject.`, bot.user.displayAvatarURL())
    .setDescription(`● **XletterTickets** à été créé par **Khd'CP-0#0667**`)
    .addField("<:stats:771375965980983297> • Statistique", "`Serveurs: "+bot.guilds.cache.size+"`\n`Salons: "+bot.channels.cache.size+"`\n`Membres: "+bot.users.cache.size+"`", true)
    .addField("<:version:771376291713777664> • Versions", "`Discord.js: "+Discord.version+"`\n`Nodejs : "+process.version+"`", true)
    .addField(":green_circle: • En ligne", "`"+(Math.round(bot.uptime / (1000 * 60 * 60))) + " heures`\n`" + (Math.round(bot.uptime / (1000 * 60)) % 60) + " minutes`\n`" + (Math.round(bot.uptime / 1000) % 60) + " secondes`", true)
    .addField("<:ram:771376534971744267> • RAM", "`"+(process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2)+"` MB");
  message.channel.send({embed});
};

exports.help = {
  name: "stats",
  aliases: ['info', "botinfo"]
};
