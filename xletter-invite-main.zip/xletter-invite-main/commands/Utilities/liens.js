const Discord = require("discord.js");

exports.run = async (bot, message, args, functions) => {

let embed = new Discord.MessageEmbed()
.setTitle(`:tickets: XletterTickets - Les liens`)
.setColor("RANDOM")
.setDescription("**__Voici les liens de support de XletterTickets:__**\n\n<a:fleche:771373429366587402> Ajoute moi sur ton serveur: [Clique ici](https://discord.com/oauth2/authorize?client_id=771371867290206208&permissions=8&scope=bot)\n<a:fleche:750809388414926932> Serveur support: [Clique ici](https://discord.gg/yukihira)")
.setFooter(`XletterTickets | Crée par XletterProject.`, bot.user.displayAvatarURL())
.setTimestamp();

message.channel.send(embed);
};

exports.help = {
    name: "liens",
    aliases: ['supp']
}
